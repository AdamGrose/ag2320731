/* 
 * File:   main.cpp
 * Author: Adam Grose
 * January 2nd, 2014
 * Project 1
 */

//System Libraries
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <cstring>
using namespace std;

//Global Constants none

//Function Prototypes
void health(int&,int&);//initializes health
void Menu();//simple menu
void battleMenu(int,int,int&,int&,int,string);//outputs turn,health,enemy,and attack options
void plDamage(int&,int&,int&,int&,string);//deals damage to computer based on which attack chosen
void attack1(int,int&,string);//Sword attack
void attack2(int,int&,string);//Fire attack
void attack3(int,int&,string);//Flurry attack
int attack4();//Potion
void plAtkScreen(int,string);//Outputs which attack used and how much damage done
void cmpDamage(int&,int&,int&,int&);//Deals damage to player based on which attack chosen
void cmpAtkScreen(int);//outputs which attack used and how much damage done
void winDecide(int,int,int,string);//Outputs who wins
void plWin(int,int,string);//player win menu
void cmpWin(int,int,string);//computer win menu

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int plHp,cmpHp,plAtck,cmpAtck,plDamg,cmpDamg,i;
    char ans;
    string name;
    //Initialize random number generator
    srand(static_cast<unsigned int>(time(0)));
    do{
        i=1;
    //Get players name
        cout<<"Enter your First name only.\n";
        cin>>name;
    //Initialize health
    health(plHp,cmpHp);
    //Game Menu
    Menu();
    //WOLF APPEARS
    cout<<endl<<endl<<"        A GIANT WOLF ATTACKS"<<endl;
    do{
    //Initialize the battle menu
    battleMenu(plHp,cmpHp,plAtck,cmpAtck,i,name);
    //Calculate and apply damage done by the player
    plDamage(plAtck,plHp,cmpHp,plDamg,name);
    //Output the attack and damage caused by the player
    plAtkScreen(plDamg,name);
    if(cmpHp>0){
    //Calculate and apply the damage done by the computer
    cmpDamage(cmpAtck,cmpHp,plHp,cmpDamg);
    //Output the attack and damage caused by the computer
    cmpAtkScreen(cmpDamg);
    }i++;
    }while(cmpHp>0&&plHp>0);
    //Output the win screen if the Player won, or if the computer won
    winDecide(plHp,cmpHp,i,name);
    //Prompt to repeat loop
    cout<<"Enter y to play again, anything else to quit.\n";
    cin>>ans;
    }while(ans=='y'||ans=='Y');
    //Exit Stage Right
    return 0;
}

void Menu(){
    int dum;
    cout<<"          ARENA    \n";
    cout<<"       BATTLE RPG   \n";
    do{
    cout<<endl<<"Enter 1 to play ";
    cin>>dum;
    if(dum!=1)cout<<"Not a valid input.\n";
    }while(dum!=1);
}

void health(int& hp1,int& hp2){
    //Computer and player hp initialized to 100
    hp1=100;
    hp2=100;
}

void battleMenu(int hp1,int hp2,int& play,int& wolf,int i,string name){
    //Outputs the players and computers current health
    cout<<name<<" hp "<<hp1<<"%";
    cout<<"              wolf hp "<<hp2<<"%"<<endl;
    //Outputs what turn it currently is
    cout<<"Turn "<<i<<endl;
    cout<<"                 _       \n";
    cout<<"                / |  __ \n";
    cout<<"               /__| /_| \n";
    cout<<"             /_(X)_|__| \n";
    cout<<"            /________| \n";
    cout<<"           /_/_______| \n";
    cout<<"           V_________| \n";
    cout<<"           /_________| \n";
    cout<<"          /___________| \n";
    cout<<"         /____________| \n";
    cout<<"                                "<<endl;
    //Output the attack menu
    cout<<"1.)Sword Attack        3.)Flurry"<<endl;
    cout<<"2.)Fire                4.)Potion"<<endl;
    do{
    //Enter a valid attack to continue if not, then player is prompted to input another number.
    cin>>play;
    if(play>4)cout<<"not a valid input.\n";
    }while(play>4||play<=0);
    cout<<endl<<endl;
    wolf=rand()%3+1;
}

void plDamage(int& attack,int& plHp,int& cmpHp,int& damage,string name){
    damage=0;
    switch(attack){
        case 1: {
            //Damage is set to sword attack and computer takes damage
            attack1(attack,damage,name);
            cmpHp-=damage;
            break;
        }
        case 2: {
            //damage is set to fire attack and computer takes damage
            attack2(attack,damage,name);
            cmpHp-=damage;
            break;
        }
        case 3: {
            //damage is set to flurry and computer takes damage
            attack3(attack,damage,name);
            cmpHp-=damage;
            break;
        }
        case 4: {
        //If player health is below 100
        if(plHp<100){
            //temp used to calculate how much hp player has lost
            int temp;
            temp=100-plHp;
            if(temp>20){
                //If player has lost more than 20 hp then player regains 20hp
                cout<<name<<" USED POTION!!!\n";
                cout<<name<<" GAINED 20 HP!!\n";
                plHp+=attack4();
                damage=0;
                break;
            }
            else{
                //If player has lost less than 20 hp then player regains full health
                cout<<name<<" USED POTION!!!\n";
                cout<<name<<" GAINED "<<temp<<" HP!!\n";
                plHp=100;
                damage=0;
                break;
            }
    }else
        //If player has full hp, then no hp is gained
        cout<<name<<" USED POTION!!!\n";
        cout<<"POTION HAD NO EFFECT!!!\n";
        damage=0;
        break;
}
}
}

void attack1(int atck,int& dmg,string name){
    //Standard attack. Does 15 damage
    cout<<name<<" USED SWORD ATTACK\n";
    dmg=15;
}

void attack2(int atck,int& dmg,string name){
    cout<<name<<" USED FIRE\n";
    //Initialize a random number to variable temp
    int temp=rand()%50+1;
    //if temp falls between 1 and 25 or 75 and 100 then the attack is successful
    if((temp<=25)||(temp>=75&&temp<=100)){
    //The fire attack does damage between 20 and 40 and anything
    //above 30 is labeled a critical hit
    dmg=rand()%(40-20)+20;
    if(dmg>=30)cout<<"CRITICAL HIT!!!\n";
}
    else{
    //If temp doesn't fall within range, the attack fails and does no damage
    cout<<"FIRE FAILED!!\n";
    
}
}

void attack3(int atck,int& dmg,string name){
    cout<<name<<" USED FLURRY\n";
    int count=0;
    dmg=0;
    //Initialize loop to repeat attack as long as the random number falls
    //between 1 and 70
    for(int i=0;i<=70;i=rand()%100+1){
        dmg+=5;
        //keeps track of how many attacks were executed
        count++;
    }
    cout<<"ATTACKED "<<count<<" TIMES\n";
}
int attack4(){
    //Returns 20 health as an integer
    int incr;
    incr=20;
    return incr;
}

void plAtkScreen(int plDamage,string name){
    int dum;
    if(plDamage>0)cout<<name<<" DEALT "<<plDamage<<" DAMAGE!!!\n"<<endl;
      
}

void cmpDamage(int& attack,int& cmpHp,int& plHp,int& damage){
    int temp;
    damage=0;
    attack=rand()%4+1;
    switch(attack){
        case 1: {
            cout<<"WOLF USED SCRATCH!!!"<<endl;
            damage=15;
            plHp-=damage;
            break;
        }
        case 2: {
            cout<<"WOLF USED BITE!!!"<<endl;
            damage=20;
            plHp-=damage;
            break;
        }
        case 3: {
            cout<<"WOLF USED RAGE!!!"<<endl;
            damage=25;
            plHp-=damage;
            break;
        }
        case 4: {
            if(cmpHp<100){
                temp=100-cmpHp;
                if(temp<=20){
                    cout<<"WOLF USED LICK. GAINED "<<temp<<" HP!!!\n";
                    damage=0;
                    cmpHp=100;
                    break;
                }else{
                    damage=0;
                    cmpHp+=20;
                    cout<<"WOLF USED LICK. GAINED 20 HP!!!\n";
                    break;
                }
            }else{
                damage=0;
                cout<<"WOLF USED LICK.\n";
                cout<<"LICK HAD NO EFFECT!\n";
            }
            break;
        }
    }
}

void cmpAtkScreen(int cmpDamage){
    int dum;
      if(cmpDamage>0)cout<<"WOLF DEALT "<<cmpDamage<<" DAMAGE!!!\n"<<endl;
    do{
    cout<<"Enter 1 to continue ";
    cin>>dum;
    if(dum!=1)cout<<"invalid input\n";
    }while(dum!=1);
}

void winDecide(int plHp,int cmpHp,int i,string name){
    if(plHp>0){
        plWin(i,plHp,name);
    }else{
        cmpWin(i,cmpHp,name);
    }
    
}

void plWin(int i,int plHp,string name){
    cout<<name<<" hp "<<plHp<<"%";
    cout<<"              wolf hp 0%"<<endl;
    cout<<"                 _/     /   /    \n";
    cout<<"                // |  _/_  /      \n";
    cout<<"               //__| //_| /       \n";
    cout<<"             /_/(X)_|/__|/        \n";
    cout<<"            /_/_____/__|/        \n";
    cout<<"           /_//____/___/|       \n";
    cout<<"           V/_____/___/_|        \n";
    cout<<"           //____/___/__|         \n";
    cout<<"          //____/___/____|        \n";
    cout<<"         //____/___/_____|        \n"; 
    cout<<"     YOU DEFEATED THE WOLF in "<<i<<" turns.\n";
}

void cmpWin(int i,int cmpHp,string name){
    cout<<name<<" hp 0%";
    cout<<"              wolf hp "<<cmpHp<<"%"<<endl;
    cout<<"                 _       \n";
    cout<<"                / |  __ \n";
    cout<<"               /__| /_| \n";
    cout<<"             /_(X)_|__| \n";
    cout<<"            /________| \n";
    cout<<"           /_/________| \n";
    cout<<"           V_________| \n";
    cout<<"           /_________| \n";
    cout<<"          /___________| \n";
    cout<<"         /____________| \n";
    cout<<"         YOU LOST in "<<i<<" turns.\n";
}
